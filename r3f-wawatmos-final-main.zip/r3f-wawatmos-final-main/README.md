![Thumbnail video tutorial](https://user-images.githubusercontent.com/6551176/233513056-525d827e-e8fa-4b57-901a-b05175505a55.jpg)

[Live Demo](https://r3f-wawatmos-final.vercel.app/)

[Video tutorial](https://youtu.be/8r8rzp8t2aM)

[Starter pack](https://github.com/wass08/r3f-wawatmos-starter)

### 3D Model credits

Airplane by Poly by Google [CC-BY](https://creativecommons.org/licenses/by/3.0/) via Poly Pizza (https://poly.pizza/m/8VysVKMXN2J)
